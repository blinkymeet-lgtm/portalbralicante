# Projeto pronto para continuar no Bolt.new

Este ZIP contém o projeto completo em **Vite + React + TypeScript + Tailwind + Supabase**, preparado para ser importado no Bolt.new e continuar o desenvolvimento.

## Como continuar no Bolt.new

1. Importe este ZIP como ficheiros/projeto.
2. Mantenha a estrutura atual de `src/`, `public/` e `supabase/`.
3. Não substitua o projeto por um template novo: continue a partir do código existente.
4. Instale as dependências com `npm install` se o ambiente do Bolt pedir.
5. Execute `npm run build` para validar o projeto.

## Variáveis de ambiente

Crie as variáveis do frontend no ambiente do Bolt:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Existe um `.env.example` apenas como referência. O `.env` com credenciais locais não é incluído neste ZIP.

## Supabase

O projeto já inclui:

- `supabase/config.toml`
- migrations da tabela `listings`
- regras de acesso/storage
- Edge Function `admin-api`

A Edge Function precisa dos secrets no Supabase:

- `ADMIN_PASSWORD`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_URL`

Nunca coloque `SUPABASE_SERVICE_ROLE_KEY` no frontend ou em variáveis `VITE_*`.

## Netlify

O projeto já inclui `netlify.toml` e `public/_redirects` para SPA routing.

Configuração esperada:

- Build command: `npm run build`
- Publish directory: `dist`
- Node: `20`

## Estrutura principal

- `src/pages/` — páginas públicas e administração
- `src/components/` — componentes reutilizáveis
- `src/lib/` — Supabase, autenticação e tipos
- `src/layouts/` — layouts público/admin
- `supabase/migrations/` — estrutura da base de dados
- `supabase/functions/admin-api/` — API administrativa
- `public/` — logos, SEO e redirects

## Nota de segurança

O fallback de palavra-passe que estava diretamente escrito na Edge Function foi removido. A palavra-passe de administrador deve ser configurada exclusivamente pelo secret `ADMIN_PASSWORD` no Supabase.
